# Neon Strike — Android shooting game

A portrait-mode, offline arcade shooter packaged in a native Android WebView.

## Play the game now
Open `app/src/main/assets/game.html` in a modern browser, or serve it locally. It works offline.

## Build an Android APK
1. Install Android Studio and a JDK 17.
2. Open this `NeonStrikeAndroid` folder in Android Studio.
3. Let Gradle sync (Android Gradle Plugin 8.7.3; compile SDK 35).
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the APK location. Install the debug APK on your Android device.

## Controls
- Drag anywhere in the play area to move the ship.
- Auto-fire is enabled.
- Keyboard: WASD or arrow keys.
- Dodge the red drones and survive for the highest score.

This source project has not been compiled in this environment, so no APK binary is included.

## Build an APK online with GitHub Actions
This project includes `.github/workflows/build-apk.yml`. Upload the extracted project to a GitHub repository, then open **Actions → Build Neon Strike APK → Run workflow**. When the workflow finishes, open its run, download the `NeonStrike-debug-apk` artifact, extract it, and install `app-debug.apk` on your Android phone. The first install may require allowing installs from that source.
